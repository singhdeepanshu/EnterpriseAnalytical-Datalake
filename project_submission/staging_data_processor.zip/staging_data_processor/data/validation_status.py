class ValidationStatus:
    SUCCESS = 0
    WARNING = 1
    FAILED = 2
